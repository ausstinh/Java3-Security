package business;



import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;

import database.VerseDataService;
import src.Models.Verse;


@Stateless
@Local(VersesBusinessInterface.class)
@Alternative
public class VersesBusinessService implements VersesBusinessInterface<Verse> {
	//Inject the Service
	@Inject
	VerseDataService services;
	
	@Override
	public Verse findVerse(String book, int chapter, int verse) {
		
		return services.findVerse(book,chapter,verse);
	} 
	

}
