package business;

import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import src.Models.User;

@RequestScoped
@Path("/users")
public class UserRestService {

	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public User getUser() {
		
		User user = new User();
		user.setFirstName("Austin");
		user.setLastName("Harvey");
		return user;
	}
	
	@GET
	@Path("/get/{firstname}/{lastname}")
	@Produces(MediaType.APPLICATION_JSON)
	public User getUser(@PathParam("firstname") String firstName, @PathParam("lastname") String lastName)
	{
		//calls a business service to search for a User but for now use an echo
		System.out.println("API was /getuser: I received request for name: " + firstName + " " + lastName);
		User user = new User();
		user.setFirstName(firstName);
		user.setLastName(lastName);
		return user;
	}
	
	@POST
	@Path("/save")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public User saveUser(User user)
	{
		System.out.println("Hello " + user.getFirstName() + " " + user.getLastName());
		return user;
	}
}
