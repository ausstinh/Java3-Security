package business;


import javax.ejb.Local;


@Local
public interface VersesBusinessInterface<T>{
	/**
     * Method returns a Verse object from the database with the requested parameters.
     * @param book - Type: String Class. Description: Name of the book where the verse is.
     * @param chapter - Type: Integer Class. Description: Number of the chapter where the verse is.
     * @param verseNumber -Type: Integer Class Description: Number of the verse.
     * @return Type: Verse Class - Description: Verse Object that matches the requested parameters.
     */
	public T findVerse(String book, int chapter, int verseNum);
}
