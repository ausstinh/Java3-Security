package business;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.inject.Inject;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import database.OrderDataService;
import src.Models.Order;

/**
 * Session Bean implementation class OrdersBusinessService
 */
@Stateless
@Local(OrdersBusinessInterface.class)
public class OrdersBusinessService implements OrdersBusinessInterface {
	@Inject
	OrderDataService orderDataService;
	@Resource(mappedName="java:/ConnectionFactory")
	private ConnectionFactory connectionFactory;

	@Resource(mappedName="java:/jms/queue/Order")
	private Queue queue;
	
		
	@Override
	public List<Order> getOrders() {
		return orderDataService.findAll();
	}
	
	public void saveOrder(Order order) {
		orderDataService.create(order);
	}

	public void sendOrder(Order order)
	{
		try
		{
			//get a connection and session to the JSM connection factory
			Connection connection = connectionFactory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			//Create a message producer for sending messages to the queue
			MessageProducer messageProducer = session.createProducer(queue);
			
			//Create and send text message
			TextMessage message1 = session.createTextMessage();
			message1.setText("This is test message");
			messageProducer.send(message1);
			
			//Create and send an object message (with the Order)
			ObjectMessage message2 = session.createObjectMessage();
			message2.setObject(order);
			messageProducer.send(message2);
			
			//Clean up by closing the connection to the JMS connection factory
			connection.close();
		}
		catch(JMSException e)
		{
			e.printStackTrace();
		}
	}

	@Override
	public void setOrders(List<Order> orders) {
		// TODO Auto-generated method stub
		
	}
	
}
