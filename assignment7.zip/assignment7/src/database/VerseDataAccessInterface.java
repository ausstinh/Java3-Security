package database;



public interface VerseDataAccessInterface <Verse>{

	public Verse findVerse(String book, int chapter, int verse);
}
