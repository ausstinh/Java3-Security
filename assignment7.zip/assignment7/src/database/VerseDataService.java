package database;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import src.Models.Verse;
@Stateless
@Local(VerseDataAccessInterface.class)
@LocalBean
public class VerseDataService implements VerseDataAccessInterface<Verse> {

	/*finds all verses in the bible database */
	
	
		java.sql.Connection conn = null;
		String url = "jdbc:mysql://localhost:8888/bible";
		String username = "root";
		String password = "root";
		@Override
	    public Verse findVerse(String book, int chapter, int verseNumber) {
	        String sql = String.format("SELECT * FROM verses WHERE book='%s' AND chapter='%d' AND versenum='%d'", book, chapter, verseNumber);
	        Verse returnVerse = null; 
	        
	        try{
	            conn = DriverManager.getConnection(url, username, password);
	            Statement stmt = conn.createStatement();
	            ResultSet rs = stmt.executeQuery(sql);
	            
	            while(rs.next()){
	                returnVerse = new Verse(rs.getString("book"), rs.getInt("chapter"), rs.getInt("versenum"), rs.getString("verse"));
	            }
	        }
	        
	        catch(SQLException e){
	            e.printStackTrace();
	        }
	        return returnVerse;
	    }

	}

