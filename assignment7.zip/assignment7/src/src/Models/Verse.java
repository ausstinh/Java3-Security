package src.Models;

public class Verse {

	String book;
	int chapter;
	int versenum;
	String verse;
	public Verse(String book, int chapter, int versenum, String verse) {
		super();
		this.book = book;
		this.chapter = chapter;
		this.versenum = versenum;
		this.verse = verse;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public int getChapter() {
		return chapter;
	}
	public void setChapter(int chapter) {
		this.chapter = chapter;
	}
	public int getVersenum() {
		return versenum;
	}
	public void setVersenum(int versenum) {
		this.versenum = versenum;
	}
	public String getVerse() {
		return verse;
	}
	public void setVerse(String verse) {
		this.verse = verse;
	}
	
}
